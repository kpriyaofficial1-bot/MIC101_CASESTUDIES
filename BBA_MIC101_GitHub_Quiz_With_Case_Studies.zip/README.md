# BBA MIC101 – Fundamentals of Entrepreneurship Live Quiz

- 10 regular MCQ sets × 10 questions = 100 unique regular questions
- 10 case-study sets × 4 questions = 40 additional case-study questions
- All four syllabus units are covered
- Regular quiz timer: 15 minutes
- Case-study quiz timer: 20 minutes
- Automatic submission and scoring
- Student name and roll number
- Mobile-friendly
- Ready for GitHub Pages

Upload index.html to the root of the MIC101_QUIZ repository, replacing the existing index.html.
